void main() {

  // vec4 texture = texture2D(t_diffuse, gl_PointCoord);

  gl_FragColor = vec4(1., 0., 0., 1.);
}
