const constants = {
  EVENTS: {
    // ASSET_LOADED: 'EVENTS.ASSET_LOADED',
  },
};

module.exports = constants;
