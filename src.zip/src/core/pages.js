export const INTRO      = 'intro';
export const PROJECT    = 'project';
//export const EXPERIMENT = 'experiment';
export const ABOUT      = 'about';
export const HOME       = 'home';

export const GENESIS    = 'genesis';
export const QUIZ       = 'quiz';
export const CONCEPT    = 'concept';
export const CODE       = 'code';
export const ROBO       = 'robo';
export const MECH       = 'mech';
export const STRG       = 'strg';
export const IBM        = 'ibm';
export const TECH       = 'tech';
export const TEAM       = 'team';
export const LOGIN	    = 'login';
export const MYKTJ	    = 'myktj';
