import getPerspectiveSize from './getPerspectiveSize';

export { getPerspectiveSize };
