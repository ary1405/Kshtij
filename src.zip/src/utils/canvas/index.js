import createCanvas from './createCanvas';
import createHexagone from './createHexagone';
import resizeCanvas from './resizeCanvas';

export { createCanvas, createHexagone, resizeCanvas };
