export default function (value, min, max) {
  return min + value * (max - min);
}
