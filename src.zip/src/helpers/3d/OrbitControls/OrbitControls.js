import OrbitControls from 'three-orbit-controls';

export default OrbitControls(THREE);
